
     <div class="navbar-main">
              
        <div class="container">

          <div class="navbar-header">
     <div class="navbar-brand">
     <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img class="img-fluid" style="vertical-align:middle" src="<?php echo e(asset('frontend/images/logo.png')); ?>" width="85px" alt=""></a>
     <div class="wrap navbar-brand" style="vertical-align:middle">
        
        <span class="thepeople" onclick="location='http://thepeople.com.au'">JAI SHRI RADHEY KRISHAN FOUNDATION</span>
        <p><span class="agency" onclick="location='http://thepeople.com.au'"><div class="squareleft" style="vertical-align:middle"></div><h4 class="subtitle" style="vertical-align:middle">Sabke Sath</h4><div class="squareright" style="vertical-align:middle"></div></span></p>
      </div>
     </div>
          </div>
</div>
<?php /**PATH E:\laravel\radhey\ngo\resources\views/frontend/layouts/brand.blade.php ENDPATH**/ ?>