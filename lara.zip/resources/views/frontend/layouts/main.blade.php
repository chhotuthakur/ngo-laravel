@include('frontend.layouts.header')
@yield('main-content')

@include('frontend.layouts.footer')