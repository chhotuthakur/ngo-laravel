<nav class="navbar navbar-static-top" style="background: white;" >

            <div class="navbar-top" >

              <div class="container-fluid" style="background-color: #e60606;" >
                  <div class="row">

                    <div class="col-sm-6 col-xs-12">

                        <ul class="list-unstyled list-inline header-contact">
                            <li> <img src="{{asset('frontend/images/logo.png')}}" width="75px" height="auto" mb-2> <a href="index.php"></a> </li>
                            <ul class="wrap" style="list-style: none">
                             <li></i><span class="thepeople" onclick="location='http://thepeople.com.au'">JAI SHRI RADHEY KRISHAN FOUNDATION</span>
                            </li>
                            <li><span class="agency" onclick="location='http://thepeople.com.au'"><div class="squareleft" style="vertical-align:middle"></div><h4 class="subtitle" style="vertical-align:middle">Sabke Sath</h4><div class="squareright" style="vertical-align:middle"></div></span></li>
                            </ul> </ul> <!-- /.header-contact  -->
                      
                    </div>

                    <div class="col-sm-6 col-xs-12 text-right">

                        <ul class="list-unstyled list-inline header-social">

                        <h6>REGD. NO. 3467/2021-22/04</h6>

                            <!-- <li> <a href="#"> <i class="fa fa-facebook"></i> </a> </li>
                            <li> <a href="#"> <i class="fa fa-twitter"></i>  </a> </li>
                            <li> <a href="#"> <i class="fa fa-google"></i>  </a> </li>
                            <li> <a href="#"> <i class="fa fa-youtube"></i>  </a> </li>
                            <li> <a href="#"> <i class="fa fa fa-pinterest-p"></i>  </a> </li> -->
                       </ul> <!-- /.header-social  -->
                      
                    </div>


                  </div>
              </div>
