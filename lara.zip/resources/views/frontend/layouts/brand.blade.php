{{-- <div class="row">

    <div class="col lg-2 sm-4"><a class="navbar-brand" href="{{url('/')}}"><img src="{{asset('frontend/images/logo.png')}}" width="85px" alt=""></a></div>
    <div class="col lg-2 sm-4"><h3 class="text-white " style="width: auto">JAI SHRI RADHEY KRISHAN FOUNDATION</h3></div>
    <div class="col lg-4 sm-4">
<div class="row">
<div class="col lg-2 sm-4"></div>
<div class="col lg-2 sm-4"><h5 class="squareleft"></h5><h6 class="subtitle">Sabke Sath</h6><h6 class="squareright"></h6></div>
<div class="col lg-2 sm-4"></p></div>

</div>


    </div>
     --}}
     <div class="navbar-main">
              
        <div class="container">

          <div class="navbar-header">
     <div class="navbar-brand">
     <a class="navbar-brand" href="{{url('/')}}"><img class="img-fluid" style="vertical-align:middle" src="{{asset('frontend/images/logo.png')}}" width="85px" alt=""></a>
     <div class="wrap navbar-brand" style="vertical-align:middle">
        
        <span class="thepeople" onclick="location='http://thepeople.com.au'">JAI SHRI RADHEY KRISHAN FOUNDATION</span>
        <p><span class="agency" onclick="location='http://thepeople.com.au'"><div class="squareleft" style="vertical-align:middle"></div><h4 class="subtitle" style="vertical-align:middle">Sabke Sath</h4><div class="squareright" style="vertical-align:middle"></div></span></p>
      </div>
     </div>
          </div>
</div>
{{-- 
<section>
    <div class="row">
<div class="col sm">
      
     
     </div>
<div class="col sm">

<p class="squareleft"></p></p>

</div>
    </div>

  
   


  </section> --}}